//
//  Cosmos.h
//  Cosmos
//
//  Created by Evgenii Neumerzhitckii on 22/06/2015.
//  Copyright © 2015 Marketplacer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Cosmos.
FOUNDATION_EXPORT double CosmosVersionNumber;

//! Project version string for Cosmos.
FOUNDATION_EXPORT const unsigned char CosmosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Cosmos/PublicHeader.h>


