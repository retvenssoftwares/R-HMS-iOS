//
//  InventoryHeaderCell.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 07/11/23.
//

import UIKit

class InventoryHeaderCell: UITableViewCell {

    @IBOutlet weak var lblVipRoom: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
