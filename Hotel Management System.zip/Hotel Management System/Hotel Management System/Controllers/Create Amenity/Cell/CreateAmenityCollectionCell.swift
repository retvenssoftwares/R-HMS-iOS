//
//  CreateAmenityCollectionCell.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 03/11/23.
//

import UIKit

class CreateAmenityCollectionCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
