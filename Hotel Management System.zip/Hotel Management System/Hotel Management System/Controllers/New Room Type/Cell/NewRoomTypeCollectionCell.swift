//
//  NewRoomTypeCollectionCell.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 14/11/23.
//

import UIKit

class NewRoomTypeCollectionCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
