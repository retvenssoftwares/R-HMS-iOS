//
//  CreateProperty HeaderCell.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 17/11/23.
//

import UIKit

class CreateProperty_HeaderCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
