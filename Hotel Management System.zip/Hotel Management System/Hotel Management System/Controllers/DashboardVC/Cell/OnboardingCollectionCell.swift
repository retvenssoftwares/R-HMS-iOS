//
//  OnboardingCollectionCell.swift
//  Retvent
//
//  Created by Smart Kamina on 02/11/23.
//

import UIKit

class OnboardingCollectionCell: UICollectionViewCell {

    @IBOutlet weak var imgBanner: UIImageView!
    @IBOutlet weak var lblHeading: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
