//
//  OverViewCollectionCell.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 09/11/23.
//

import UIKit

class OverViewCollectionCell: UICollectionViewCell {

    // MARK: - outlet
    @IBOutlet weak var viewBG: UIView!
    
    // MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

}
