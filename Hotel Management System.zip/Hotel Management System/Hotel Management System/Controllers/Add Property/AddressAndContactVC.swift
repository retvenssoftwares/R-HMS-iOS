//
//  AddressAndContactVC.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 04/11/23.
//

import UIKit

class AddressAndContactVC: UIViewController {
    
    
    // MARK: - Outlet
    @IBOutlet weak var btnContinue: UIButton!
    @IBOutlet weak var viewAddressLine1: UIView!
    @IBOutlet weak var txtFieldAddressLine1: UITextField!
    @IBOutlet weak var viewAddressLine2: UIView!
    @IBOutlet weak var txtFieldAddressLine2: UITextField!
    @IBOutlet weak var viewCIty: UIView!
    @IBOutlet weak var txtFieldCity: UITextField!
    @IBOutlet weak var viewZipCode: UIView!
    @IBOutlet weak var txtFieldZipCode: UITextField!
    @IBOutlet weak var viewCountryName: UIView!
    @IBOutlet weak var txtFielldCountry: UITextField!
    @IBOutlet weak var viewStateName: UIView!
    @IBOutlet weak var txtFieldState: UITextField!
    @IBOutlet weak var viewPhone: UIView!
    @IBOutlet weak var txtFieldPhone: UITextField!
    @IBOutlet weak var viewReservationPhone: UIView!
    @IBOutlet weak var txtFieldReservationPhone: UITextField!
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var txtFieldEmail: UITextField!
    @IBOutlet weak var viewWebsite: UIView!
    @IBOutlet weak var txtFieldWebsite: UITextField!
    
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
 
        btnContinue.layer.cornerRadius = 5
        textFieldBorderLine()
        textFieldPlaceHolderTextChange()
    }
    
    // MARK: - Function
    func textFieldBorderLine(){
        viewAddressLine1.layer.borderWidth = 1
        viewAddressLine1.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewAddressLine1.layer.cornerRadius = 10
        
        viewAddressLine2.layer.borderWidth = 1
        viewAddressLine2.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewAddressLine2.layer.cornerRadius = 10
        
        viewCIty.layer.borderWidth = 1
        viewCIty.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewCIty.layer.cornerRadius = 10
        
        viewZipCode.layer.borderWidth = 1
        viewZipCode.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewZipCode.layer.cornerRadius = 10
        
        viewCountryName.layer.borderWidth = 1
        viewCountryName.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewCountryName.layer.cornerRadius = 10
        
        viewCountryName.layer.borderWidth = 1
        viewCountryName.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewCountryName.layer.cornerRadius = 10
        
        viewStateName.layer.borderWidth = 1
        viewStateName.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewStateName.layer.cornerRadius = 10
        
        viewPhone.layer.borderWidth = 1
        viewPhone.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewPhone.layer.cornerRadius = 10
        
        viewReservationPhone.layer.borderWidth = 1
        viewReservationPhone.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewReservationPhone.layer.cornerRadius = 10
        
        viewEmail.layer.borderWidth = 1
        viewEmail.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewEmail.layer.cornerRadius = 10
        
        viewWebsite.layer.borderWidth = 1
        viewWebsite.layer.borderColor = UIColor.init(named: "TextFiledViewLine")?.cgColor
        viewWebsite.layer.cornerRadius = 10
    }
    
    
     func textFieldPlaceHolderTextChange(){
         let color = UIColor.init(named: "TextColor")
         txtFieldAddressLine1.attributedPlaceholder = NSAttributedString(string: txtFieldAddressLine1.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldAddressLine2.attributedPlaceholder = NSAttributedString(string: txtFieldAddressLine2.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldCity.attributedPlaceholder = NSAttributedString(string: txtFieldCity.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldZipCode.attributedPlaceholder = NSAttributedString(string: txtFieldZipCode.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFielldCountry.attributedPlaceholder = NSAttributedString(string: txtFielldCountry.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldState.attributedPlaceholder = NSAttributedString(string: txtFieldState.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldPhone.attributedPlaceholder = NSAttributedString(string: txtFieldPhone.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldReservationPhone.attributedPlaceholder = NSAttributedString(string: txtFieldReservationPhone.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldEmail.attributedPlaceholder = NSAttributedString(string: txtFieldEmail.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         txtFieldWebsite.attributedPlaceholder = NSAttributedString(string: txtFieldWebsite.placeholder!, attributes: [NSAttributedString.Key.foregroundColor : color!])
         
         
    }
    

    // MARK: - Action
    

  
    @IBAction func addPropertyBtnPressed(_ sender: UIButton) {
    }
    @IBAction func cancelBtnPressed(_ sender: UIButton) {
    }
    
    @IBAction func continueBtnPressed(_ sender: UIButton) {
    }
}
