//
//  AddressAndContactVC.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 04/11/23.
//

import UIKit


class AddressAndContactVC: UIViewController {
    
    
    // MARK: - Outlet

    @IBOutlet weak var viewGoogleMaps: UIView!
    
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
 
     
    }
    
    // MARK: - Function
 
  
    

    // MARK: - Action
    

  
  
}
