//
//  CreateRoomRateCollectionCell.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 06/11/23.
//

import UIKit

class CreateRoomRateCollectionCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
