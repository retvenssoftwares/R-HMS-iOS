//
//  CreateRoomCollectionCell.swift
//  Hotel Management System
//
//  Created by Smart Kamina on 04/11/23.
//

import UIKit

class CreateRoomCollectionCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
